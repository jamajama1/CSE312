var count = 0;

function counter() {
    count = count + 1;
    document.getElementById("counter").innerHTML = count;
};